module yAdder(z, cout, a, b, cin);

output [31:0] z;
output cout;
input [31:0] a, b;
input cin;
wire[31:0] in, out;
yAdder1 mine[31:0](z, out, a, b, in);
assign in[0] = cin;

genvar i;
generate
for (i = 0; i < 31; i = i + 1) begin
      assign in[i+1] = out[i];
    end
endgenerate

assign cout = out[31];

endmodule

//---------------------------------------------------------------

module yAdder1(z, cout, a, b, cin);

output z, cout;
input a, b, cin;
xor left_xor(tmp, a, b);
xor right_xor(z, cin, tmp);
and left_and(outL, a, b);
and right_and(outR, tmp, cin);
or my_or(cout, outR, outL);

endmodule

//---------------------------------------------------------------

module yAlu(z, zero, a, b, op);

    input [31:0] a, b;
    input [2:0] op;
    output [31:0] z;
    output zero;

    wire [31:0] a0, a1, a2, slt, tmp;
    wire cout;
    wire sub;
    wire condition;

    assign sub = 1;
    assign slt[31:1] = 0;

    assign a0 = a & b;
    assign a1 = a | b;

    yArith arith(a2, cout, a, b, op[2]);

    xor(condition, a[31], b[31]);
    yArith subtract(tmp,cout,a,b,sub);
    yMux1 mux1(slt[0],tmp[31],a[31],condition);


    yMux4to1 #(.SIZE(32)) mux(z, a0, a1, a2, slt, op[1:0]);

     assign zero = (z == 32'b0) ? 1'b1 : 1'b0;

endmodule

//---------------------------------------------------------------

module yArith(z, cout, a, b, ctrl);

// add if ctrl=0, subtract if ctrl=1

output [31:0] z;
output cout;
input [31:0] a, b;
input ctrl;
wire[31:0] notB, tmp;
wire cin;

// instantiate the components and connect them
// Hint: about 4 lines of code

assign notB = ~b;
assign tmp = ctrl ? notB : b;
assign cin = ctrl;
yAdder mine(z, cout, a, tmp, cin);


endmodule

//---------------------------------------------------------------

module yMux(z, a, b, c);
parameter SIZE = 2;
output [SIZE-1:0] z;
input [SIZE-1:0] a, b;
input c;
yMux1 mine[SIZE-1:0](z, a, b, c);
endmodule

//---------------------------------------------------------------

module yMux1(z, a, b, c);

output z;
input a, b, c;
wire notC, upper, lower;
not my_not(notC, c);
and upperAnd(upper, a, notC);
and lowerAnd(lower, c, b);
or my_or(z, upper, lower);

endmodule

//---------------------------------------------------------------

module yMux2(z, a, b, c);
output [1:0] z;
input [1:0] a, b;
input c;
yMux1 upper(z[0], a[0], b[0], c);
yMux1 lower(z[1], a[1], b[1], c);
endmodule

//---------------------------------------------------------------

module yMux4to1(z, a0,a1,a2,a3, c);
parameter SIZE = 2;
output [SIZE-1:0] z;
input [SIZE-1:0] a0, a1, a2, a3;
input [1:0] c;
wire [SIZE-1:0] zLo, zHi;

yMux #(SIZE) lo(zLo, a0, a1, c[0]);
yMux #(SIZE) hi(zHi, a2, a3, c[0]);
yMux #(SIZE) final(z, zLo, zHi, c[1]);
endmodule

//---------------------------------------------------------------

module yIF(ins, PCp4, PCin, clk);

output [31:0] ins, PCp4;
input [31:0] PCin;
input clk;
wire [31:0] z, memIn;
wire zero, enable, read, write;
wire [2:0] op;
wire [31:0] b;
assign op = 2;
assign b = 4;
assign enable = 1, read = 1, write = 0;

register #(32) PC(z, PCin, clk, enable);
mem data(ins, z, memIn, clk, read,write);
yAlu alu(PCp4, zero, b, z, op);

endmodule

//---------------------------------------------------------------

module yID(rd1, rd2, imm, jTarget, ins, wd, RegDst, RegWrite, clk);

output [31:0] rd1, rd2, imm;
output [25:0] jTarget;
input [31:0] ins, wd;
input RegDst, RegWrite, clk;
wire [4:0] tmp, wn, rn1, rn2;
assign rn1 = ins[25:21];
assign rn2 = ins[20:16];
assign tmp = ins[15:11];

yMux #(5) mux(wn, rn2, tmp, RegDst);
rf myRF(rd1, rd2, rn1, rn2, wn, wd, clk, RegWrite);

assign imm = {{16{ins[15]}}, ins[15:0]};

assign jTarget = ins[25:0];

endmodule

//---------------------------------------------------------------

module yEX(z, zero, rd1, rd2, imm, op, ALUSrc);
output [31:0] z;
output zero;
input [31:0] rd1, rd2, imm;
input [2:0] op;
input ALUSrc;
wire [31:0] b;

yMux #(32) mux(b, rd2, imm, ALUSrc);
yAlu alu(z, zero, rd1, b, op);

endmodule

//---------------------------------------------------------------

module yDM(memOut, z, rd2, clk, MemRead, MemWrite);
output [31:0] memOut;
input [31:0] rd2, z;
input clk, MemRead, MemWrite;
mem data(memOut, z, rd2, clk, MemRead, MemWrite);
endmodule

//---------------------------------------------------------------

module yWB(wb, exeOut, memOut, Mem2Reg);
output [31:0] wb;
input [31:0] exeOut, memOut;
input Mem2Reg;
// instantiate the circuit (only one line)
yMux #(32) mux(wb, memOut, exeOut, Mem2Reg);
endmodule

//---------------------------------------------------------------

module yPC(PCin, PCp4,INT,entryPoint,imm,jTarget,zero,branch,jump);
output [31:0] PCin;
input [31:0] PCp4, entryPoint, imm;
input [25:0] jTarget;
input INT, zero, branch, jump;

wire [31:0] immX4, bTarget, choiceA, choiceB, jumpTarget;
wire doBranch, zf;

assign immX4[31:2] = imm[29:0];
assign immX4[1:0] = 2'b00;
assign jumpTarget = {PCp4[31:28], jTarget, 2'b00};

yAlu myALU(bTarget, zf, PCp4, immX4, 3'b010);
and (doBranch, branch, zero);
yMux #(32) mux1(choiceA, PCp4, bTarget, doBranch);
yMux #(32) mux2(choiceB, choiceA, jumpTarget, jump);
yMux #(32) mux3(PCin, choiceB, entryPoint, INT);
endmodule

//---------------------------------------------------------------

module yC1(rtype, lw, sw, jump, branch, opCode);
output rtype, lw, sw, jump, branch;
input [5:0] opCode;

wire not5, not4, not3, not2, not1, not0;
not (not5, opCode[5]);
not (not4, opCode[4]);
not (not3, opCode[3]);
not (not2, opCode[2]);
not (not1, opCode[1]);
not (not0, opCode[0]);
and (lw, opCode[5], not4, not3, not2, opCode[1], opCode[0]);
and (sw, opCode[5], not4, opCode[3], not2, opCode[1], opCode[0]);
and (branch, not5, not4, not3, opCode[2], not1, not0);
and (jump, not5, not4, not3, not2, opCode[1]);
and (rtype, not5, not4, not3, not2, not1, not0);

endmodule

//---------------------------------------------------------------

module yC2(RegDst, ALUSrc, RegWrite, Mem2Reg, MemRead, MemWrite, rtype, lw, sw, branch,jump);
output RegDst, ALUSrc, RegWrite, Mem2Reg, MemRead, MemWrite;
input rtype, lw, sw, branch, jump;

assign RegDst = rtype;
nor (ALUSrc, rtype, branch);
nor(RegWrite, sw, branch,jump);
not(Mem2Reg,lw);
assign MemRead = lw;
assign MemWrite = sw;

endmodule

//---------------------------------------------------------------

module yC3(ALUop, rtype, branch);
output [1:0] ALUop;
input rtype, branch;
// build the circuit
// Hint: you can do it in only 2 lines
assign ALUop[0] = branch;
assign ALUop[1] = rtype;

endmodule

//---------------------------------------------------------------

module yC4(op, ALUop, fnCode);
output [2:0] op;
input [5:0] fnCode;
input [1:0] ALUop;
wire or1,not1,not2,and1;

// instantiate and connect
or(or1, fnCode[3], fnCode[0]);
and(op[0],or1, ALUop[1]);

not(not1, ALUop[1]);
not(not2, fnCode[2]);
or(op[1],not1,not2);

and(and1,ALUop[1],fnCode[1]);
or(op[2],and1,ALUop[0]);

endmodule

//---------------------------------------------------------------

module yChip(ins, rd2, wb, entryPoint, INT, clk);
output [31:0] ins, rd2, wb;
input [31:0] entryPoint;
input INT, clk;

wire [2:0] op;
wire [31:0] wd, rd1, rd2, imm, ins, PCp4, z, memOut, wb, PCin;
wire [25:0] jTarget;
wire [5:0] opCode, fnCode;
wire [1:0] ALUop;
wire zero, RegDst, RegWrite, ALUSrc, Mem2Reg, MemRead, MemWrite, jump, branch, rtype, lw, sw;

yIF myIF(ins, PCp4, PCin, clk);
yID myID(rd1, rd2, imm, jTarget, ins, wd, RegDst, RegWrite, clk);
yEX myEx(z, zero, rd1, rd2, imm, op, ALUSrc);
yDM myDM(memOut, z, rd2, clk, MemRead, MemWrite);
yWB myWB(wb, z, memOut, Mem2Reg);
assign wd = wb;
yPC myPC(PCin, PCp4,INT,entryPoint,imm,jTarget,zero,branch,jump);
assign opCode = ins[31:26];
yC1 myC1(rtype, lw, sw, jump, branch, opCode);
yC2 myC2(RegDst, ALUSrc, RegWrite, Mem2Reg, MemRead, MemWrite,
 rtype, lw, sw, branch, jump);
assign fnCode = ins[5:0];
yC3 myC3(ALUop, rtype, branch);
yC4 myC4(op, ALUop, fnCode);

endmodule
